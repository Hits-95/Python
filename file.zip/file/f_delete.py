# delete file
import os
if os.remove("online3.txt") is None:
    print("FIlE deleted...")
