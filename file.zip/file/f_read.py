#open 'online.txt' in read mode...

fp = open("online.txt",'r')
for x in fp:
    print(x)

    
